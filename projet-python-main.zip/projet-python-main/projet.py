




"""def carte_to_chaine(dico):
    P = chr(9824)
    C = chr(9825)
    K = chr(9826)
    T = chr(9827)
    v = dico["valeur"]
    valeur = ""

    if type(v)==str:

        valeur = " " + v
        
    else:

        if (v//10) == 0:
            
            valeur = " " + str(v)

        else :

            valeur = str(v)


    if dico["couleur"] == 'P':
            valeur = valeur + P
    elif dico["couleur"] == 'C':
            valeur = valeur + C
    elif dico["couleur"]=='K':
            valeur = valeur + K
    elif dico["couleur"]=='T':
            valeur = valeur + T
            
    return valeur"""

def carte_to_chaine(dico):
    couleurs={'P': chr(9824),
              'C' : chr(9825),
              'K' : chr(9826),
              'T' : chr(9827)}

    v = dico["valeur"]
    
    valeur = ""

    if type(v)==str: valeur = " " + v + couleurs[dico["couleur"]] 
        
    else:

        if (v//10) == 0: valeur = " " + str(v) + couleurs[dico["couleur"]]
            
        else: valeur = str(v) + couleurs[dico["couleur"]]
   
    return valeur


def affichher_reussite(liste):
    resultat = ""
    for e in liste:
        resultat = resultat + carte_to_chaine(e) + " "
    print(resultat + "\n\n")


# Entrées / Sorties avec des fichiers
def init_pioche_fichier(nomFichier):
    f= open(nomFichier)
    liste=[]
    
    for e in f:
        liste.append(e)
        print("\n")
    f.close()
    return liste 



# Entrées / Sorties avec des fichiers
# question 4.2.1
def init_pioche_fichier(nomFichier):
    f = open(nomFichier, 'r')
    liste_carte = []
    for e in f.readlines():
        liste_carte.extend(e.split())# split permet de separee les element
    f.close()
    return liste_carte


# question 4.2.2
def ecrire_fichier_reussite(nomFichier, liste_pioche):
    f = open(nomFichier, 'w')
    carte_pioche = ""
    for e in liste_pioche:
        carte_pioche = carte_pioche + e + " "   # mettre les elements de la liste de pioche en une seule chaine de caracteres
    carte_pioche = carte_pioche.strip() # pour enlever les espaces de debut et de fin.
    f.write(carte_pioche)
    f.close()

# question 4.3

import random

def init_pioche_alea(nb_cartes=32):
    carte = 'VC 8-P VK AC 10-P 8-T 8-K 9-T VP AP 10-K 9-P 7-T RT 10-C 9-K 9-C DT RC 8-C DK 7-C AT 7-P VT 7-K CC AK DP 10-T RK RP'
    liste_carte = carte.split() # transformer la chaine en liste
    pioche_melange = random.sample(liste_carte, nb_cartes) # tirer aleatoirement nb_cartes

    return pioche_melange

# question 4.4
# 4.4.1
def alliance(carte1, carte2):
    trouve= False
    if (carte1['valeur']== carte2['valeur'] or carte1['couleur']== carte2['couleur']):
        trouve= True
    return trouve
# 4.4.2
#def saut_si_possible( liste_tas, num_carte):

    #liste_tas = init_pioche_alea(num_carte)
    #return liste_tas

def saut_si_possible( liste_tas, num_tas):
    val_retour = alliance(liste_tas[num_tas - 1], liste_tas[num_tas + 1])
    if(val_retour == True):
        del liste_tas[num_carte - 1]
        return True
    else:
        return False
    


                          


                          
                          

                          
                          
    
    
     
           

    
    






        
      # {'valeur': 17, 'couleur': 'T'}
        #print(carte_to_chaine({'valeur':7, 'couleur': 'T'}))
    #print(carte_to_chaine({'valeur':10, 'couleur': 'T'}))
    
if __name__=="__main__":
    print(carte_to_chaine({'valeur':10, 'couleur': 'T'}))
    print(carte_to_chaine({'valeur':'R', 'couleur': 'P'}))
    #----------------------------- question 4.1.2
    liste=[{'valeur':7, 'couleur': 'T'}, {'valeur':10, 'couleur': 'K'}, {'valeur':'R', 'couleur': 'C'}]
    affichher_reussite(liste)

    #----------------------------- question 4.2.1
    liste_carte = init_pioche_fichier('data_init.txt')
    print(len(liste_carte))
    print('liste de carte du fichier data_init :', liste_carte)

    #----------------------------- question 4.2.2
    ecrire_fichier_reussite("ordre.txt", liste_carte)

    # ----------------------------- question 4.3
    pioche_melange = init_pioche_alea(nb_cartes=32)
    print(pioche_melange)
    # ----------------------------- question 4.4.1
    carte1={'valeur':7, 'couleur':'P'}
    carte2={'valeur':7, 'couleur':'C'}
    resultat=alliance(carte1, carte2)
    print(resultat)
    # ----------------------------- question 4.4.1
    carte1={'valeur':7, 'couleur':'P'} # autre exemple
    carte2={'valeur':'R', 'couleur':'C'}
    resultat=alliance(carte1, carte2)
    print(resultat)
    # ----------------------------- question 4.4.2
    print(saut_si_possible( liste, 1))
    print(liste)
    
    

























"""def carte_to_chaine(dico):
    couleurs={'P': chr(9824),
              'C' : chr(9825),
              'K' : chr(9826),
              'T' : chr(9827)}

    v = dico["valeur"]
    
    valeur = ""

    if type(v)==str: valeur = " " + v + couleurs[dico["couleur"]] 
        
    else:

        if (v//10) == 0: valeur = " " + str(v) + couleurs[dico["couleur"]]
            
        else: valeur = str(v) + couleurs[dico["couleur"]]
   
    return valeur


def afficher_reussite(liste):
    resultat = ""
    for e in liste:
        resultat = resultat + carte_to_chaine(e) + " "
    print(resultat + "\n")
    


# Entrées / Sorties avec des fichiers
def init_pioche_fichier(nomFichier):
    f= open(nomFichier)
    liste=[]
    
    for e in f:
        liste.append(e)
        print("\n\n")
    f.close()
    return 



# Entrées / Sorties avec des fichiers
# question 4.2.1
def init_pioche_fichier(nomFichier):
    f = open(nomFichier, 'w')
    liste_carte = []
    for e in f.lines():
        liste_carte.extend(e.shuffle())# split permet de separee les element
    f.close()
    return liste_carte


# question 4.2.2
def ecrire_fichier_reussite(nomFichier, liste_pioche):
    f = open(nomFichier, 'w')
    carte_pioche = ""
    for e in liste_pioche:
        carte_pioche = carte_pioche + e + " "   # mettre les elements de la liste de pioche en une seule chaine de caracteres
    carte_pioche = carte_pioche.strip() # pour enlever les espaces de debut et de fin.
    f.write(carte_pioche)
    f.close()

# question 4.3

import random

def init_pioche_alea(nb_cartes=32):
    carte = 'VC 8-P VK AC 10-P 8-T 8-K 9-T VP AP 10-K 9-P 7-T RT 10-C 9-K 9-C DT RC 8-C DK 7-C AT 7-P VT 7-K CC AK DP 10-T RK RP'
    liste_carte = carte.split() # transformer la chaine en liste
    pioche_melange = random.sample(liste_carte, nb_cartes) # tirer aleatoirement nb_cartes

    return pioche_melange

# question 4.4
# 4.4.1
def alliance(carte1, carte2):
    trouve = False
    if (carte1['valeur'] == carte2['valeur'] or carte1['couleur'] == carte2['couleur']):
        trouve = True
    return trouve
# 4.4.2

def saut_si_possible( liste_tas, num_tas):
    l = list(liste_tas)
    trouve = True
    val_retour = alliance(l[num_tas - 1], l[num_tas + 1])
    if(val_retour == True):
        del l[num_tas - 1]
        trouve = True

    return trouve                          
                          

                          
                          
    
    
     
           

    
    






        
      # {'valeur': 17, 'couleur': 'T'}
        #print(carte_to_chaine({'valeur':7, 'couleur': 'T'}))
    #print(carte_to_chaine({'valeur':10, 'couleur': 'T'}))
    
if __name__=="__main__":
    print(carte_to_chaine({'valeur':10, 'couleur': 'T'}))
    print(carte_to_chaine({'valeur':'R', 'couleur': 'P'}))
    #----------------------------- question 4.1.2
    liste=[{'valeur':7, 'couleur': 'T'}, {'valeur':10, 'couleur': 'K'}, {'valeur':7, 'couleur': 'C'}]
    afficher_reussite(liste)

    #----------------------------- question 4.2.1
    liste_carte = init_pioche_fichier('data_init.txt')
    print(len(liste_carte))
    print('liste de carte du fichier data_init :', liste_carte)

    #----------------------------- question 4.2.2
    ecrire_fichier_reussite("ordre.txt", liste_carte)

    # ----------------------------- question 4.3
    pioche_melange = init_pioche_alea(nb_cartes=32)
    print(pioche_melange)
    # ----------------------------- question 4.4.1
    carte1={'valeur':7, 'couleur':'P'}
    carte2={'valeur':7, 'couleur':'C'}
    resultat=alliance(carte1, carte2)
    print(resultat)
    # ----------------------------- question 4.4.1
    carte1={'valeur':7, 'couleur':'P'} # autre exemple
    carte2={'valeur':'R', 'couleur':'C'}
    resultat=alliance(carte1, carte2)
    print(resultat)
    # ----------------------------- question 4.4.2
    print(saut_si_possible( liste, 1))
    print(liste)"""
    
    
    
    
   
    
   
    
    
    
    
