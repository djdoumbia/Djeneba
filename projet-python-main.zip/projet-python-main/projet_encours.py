
def carte_to_chaine(dico):
    couleurs={'P': chr(9824),
              'C' : chr(9825),
              'K' : chr(9826),
              'T' : chr(9827)}

    v = dico["valeur"]
    
    valeur = ""

    if type(v)==str: valeur = " " + v + couleurs[dico["couleur"]]     
    else:
        if (v//10) == 0: valeur = " " + str(v) + couleurs[dico["couleur"]]    
        else: valeur = str(v) + couleurs[dico["couleur"]]
    return valeur
    
def afficher_reussite(liste):
    resultat = ""
    for e in liste:
        resultat = resultat + carte_to_chaine(e) + " "
    print(resultat + "\n")

# Entrées / Sorties avec des fichiers
# question 4.2.1
def init_pioche_fichier(nom_fichier):
    f = open(nom_fichier) 
    ligne = f.read()
    liste  = ligne.split()
    for i in range(len(liste)):
        if liste[i][0] == '1':
            liste[i] = {'valeur': int(liste[i][0] + liste[i][1]), 'couleur': liste[i][2]}
        elif liste[i][0] in {'A', 'V', 'D', 'R'}:
            liste[i] = {'valeur': str(liste[i][0]), 'couleur': liste[i][1]}
        else:
            liste[i] = {'valeur':int(liste[i][0]), 'couleur': liste[i][1]}  
    f.close()
    return  liste

"""def init_pioche_fichier(nom_fichier):
    f = open(nom_fichier)
    ligne = f.read()
    liste  = ligne.split(" ")
    print(liste)
    liste_cartes = []
    for e in liste:
        dico = {}
        if len(e) == 2:
            dico['valeur'] = e[0]
            dico['couleur'] = e[1]
        else:
            if e[0] == '1':
                dico['valeur'] = int(e[0] + e[1]) #['8', 'P']
            else:
                dico['valeur'] = int(e[0])
            dico['couleur'] = e[-1] 
        liste_cartes.append(dico)
    return liste_cartes"""
def ecrire_fichier_reussite(nom_fichier, liste_cartes):
    carte = liste_cartes[0]
    ch = str(carte['valeur']) + carte['couleur'] if isinstance(carte['valeur'], str) else str(carte['valeur']) + '-' + carte['couleur']
    for i in range(1, len(liste_cartes)):
        carte = liste_cartes[i]
        ch1 = str(carte['valeur']) + carte['couleur'] if isinstance(carte['valeur'], str) else str(carte['valeur']) + '-' + carte['couleur']
        ch = ch + ' ' + ch1
    with open(nom_fichier, 'w') as f:
        f.write(ch)
        print('liste_cartes ajoutée avec succès au fichier')
"""def ecrire_fichier_reussite(nomFichier, liste_pioche):
    f = open(nomFichier, 'w')
    for e in liste_pioche: 
        f.write(e+'')
    print('liste_cartes ajoutée avec succès au fichier')
    f.close()"""
# question 4.3

import random
def init_pioche_alea(nb_cartes=32):
    l = [] 
    couleur = ['C', 'K', 'T', 'P']
    if nb_cartes == 32:
        valeur = [7, 8, 9, 10,'A','D','V','R']
    elif nb_cartes == 52:
        valeur = [2, 3, 4, 5, 6, 7, 8, 9, 10,'A','D','V','R']
    for i in couleur:
        for j in valeur:
            l.append({'valeur':j, 'couleur': i})
    random.shuffle(l)
            
    return l 

# question 4.4
# 4.4.1
def alliance(carte1, carte2):
    trouve= False
    if (carte1['valeur']== carte2['valeur'] or carte1['couleur']== carte2['couleur']):
        trouve= True
    return trouve
# 4.4.2
def saut_si_possible(liste_tas, num_tas):
    carte1 = liste_tas[num_tas - 1]
    carte2 = liste_tas[num_tas + 1]
    retour = alliance(carte1, carte2)
    if (retour == True ):
        del liste_tas[num_tas - 1]#del permet de supprimer une element d'une liste avec son indice
        return True
    else:
        return False

# 4.4.3    
def affichers_reussite(liste):# pour cette affichers_reussite elle est different de celle au dessus car je lai implémenter pour qu'elle puisse m'aider à afficher mes etape a chaque pioche , saut ou quiter
    resultat = ""
    for e in liste:
        resultat = resultat + carte_to_chaine(e) + " "
    print(resultat + "\n")

def une_etape_reussite(liste_tas, liste_pioche, affiche = False):
    carte = liste_pioche[0]
    if affiche: 
        print('carte piochee : ')
        affichers_reussite([carte])
    del liste_pioche[0]
    liste_tas.append(carte)
    if affiche: 
        print('Liste des tas après pioche :')
        affichers_reussite(liste_tas)
        
    num_tas = len(liste_tas) - 2
    if saut_si_possible(liste_tas, -2) :
        if affiche: 
            print('Liste des tas après saut ', num_tas, ':')
            affichers_reussite(liste_tas)
        i = 0
        while i < (len(liste_tas) - 2):
            changement = False
            if saut_si_possible(liste_tas, i+1):
                if affiche: 
                    print('Liste des tas après saut ', i + 1, ':')
                    affichers_reussite(liste_tas)
                changement = True
                i = 0
                
            if not changement : #if changement == False
                    i += 1
def reussite_mode_auto(liste_pioche, affiche = False):
    pioche = liste_pioche.copy()
    if affiche == True: 
        print('******************** Pioche ********************************')
        affichers_reussite(pioche)
    
    liste_tas = [pioche[0], pioche[1], pioche[2]] # pioche[0:3] ----> slicing ou indexing
    del pioche[:3]
    i = 1
    while  len(pioche) != 0:
        print("================ etape ", i)
        une_etape_reussite(liste_tas, pioche, affiche = affiche)
        i += 1
    return liste_tas

def menu():
        print("Menu")
        print("p : piocher")
        print("s : Sauter")
        print("# : Quitter\n")
    
def reussite_mode_manuel(liste_pioche, nb_tas_max = 2):
    affichers_reussite(liste_pioche)
    lis_tas =[liste_pioche[0], liste_pioche[1], liste_pioche[2]] #liste_pioche[:3]
    del liste_pioche[:3]
    print('Liste initiale des tas :')
    affichers_reussite(lis_tas)
    while liste_pioche:
        menu()
        choix = input("saisie une option:")
        if choix == 'p':
            carte = liste_pioche[0]
            del liste_pioche[0]
            print("carte piochée : ")
            affichers_reussite([carte])
            lis_tas.append(carte)
            print("Liste des tas après pioche : ")
            affichers_reussite(lis_tas)
        elif choix == 's':
            affichers_reussite(lis_tas)
            num_tas = int(input(f"donner le numero de tas à sauter entre 1 et {len(lis_tas) - 2} : "))
            if saut_si_possible(lis_tas, num_tas)== False:
                print(f"Impossible de faire sauter le tas d'indice {num_tas}.\n")
            else:
                print("Liste des tas après saut d'indice {}".format(num_tas))
                affichers_reussite(lis_tas)
        elif choix == '#':
            print("vous avez quiter le jeu\n")
            while liste_pioche:
                carte = liste_pioche[0]
                print("carte piochée: ")
                affichers_reussite([carte])
                del liste_pioche[0]
                lis_tas.append(carte)
                print("liste des tas après pioche : ")
                affichers_reussite(lis_tas)

            print('\n\n ==== Liste finale des tas :')
            affichers_reussite(lis_tas)
            if len(lis_tas) <= nb_tas_max:
                print("------------ vous avez gagné la partie\n")
                
            else:
                print("------------ vous avez perdu la partie\n")
            
            return lis_tas


    print("=================== Partie terminée =======================\n\n")
    print('\n\n ==== Liste finale des tas :')
    affichers_reussite(lis_tas)
    if len(lis_tas) <= nb_tas_max:
        print("------------ vous avez gagné la partie\n")
    else:
         print("------------ vous avez perdu la partie\n")
              
    return lis_tas

            
            
        
def lance_reussite(mode, nb_cartes = 32, nb_tas_max = 2, affiche = False):
     
    liste_pioche = init_pioche_alea(nb_cartes=32)
    if mode == 'auto':
        apel_reussite_auto = reussite_mode_auto(liste_pioche, affiche = affiche)
        return apel_reussite_auto
    elif mode == 'manuel':
        apel_reussite_manuel = reussite_mode_manuel(liste_pioche, nb_tas_max = 2)
        return apel_reussite_manuel
    else:
        print("Ce mode n'existe pas - selectionnez mode auto ou manuel")

#5 Partie Extension

def aux(l):
    li = []
    for i in range(len(l)):
        if l[i] not in l[i + 1:]:
            li.append(l[i])
    return li
def verifier_pioche(liste_pioche, nb_cartes = 32):
    liste = liste_pioche.copy()
    new_liste = aux(liste) 
    if len(new_liste) == nb_cartes :
        return True 
    else :
        return  False  
    
"""def verifier_pioche(liste_pioche, nb_cartes = 32): # la fonction set ne marche pas c'est pourquoi j'ai crée une fonction auxiliére pour faire verifier pioche
    new_liste = list(set(liste_pioche))
    print(len(new_liste))
    if len(list(set(liste_pioche))) == nb_cartes:
        
        return True
    else:
        return False"""
            
            
def res_multi_simulation(nb_sim, nb_cartes = 32):
    liste = []
    i = 0
    while i < nb_sim :
        liste_pioche = init_pioche_alea(nb_cartes=nb_cartes)
        retour = reussite_mode_auto(liste_pioche)
        liste.append(len(retour))
        i+=1
    return liste

def statistiques_nb_tas(nb_sim, nb_cartes = 32):
    valeur = res_multi_simulation(nb_sim, nb_cartes = nb_cartes)
    print(valeur)
    max = valeur[0]
    min = valeur[0]
    somme = 0
    for e in valeur:
        somme = somme + e
        if e >= max:
            max=e
        if e <= min :
            min=e
    moyenne = somme/nb_sim
    print("la moyenne est moyenne", moyenne)
    print("la maximum est max", max)
    print("Le minimum est min ", min)
    return moyenne, max, min


import matplotlib.pyplot as plt # import matplotlib.pyplot as plt pour ce logiciel qui spyder elle marche bien par contre pour idle ça marche et vraiment on a pas pu  avoir des solutions pour resoudre le probléme 
   
def proba(nb_sim, liste_nb_tas_max, nb_cartes = 32):
    liste_proba = []
    for i in range(len(liste_nb_tas_max)):
        retour = res_multi_simulation(nb_sim, nb_cartes=nb_cartes)

        comp = 0
        for e in retour:
            if e <= liste_nb_tas_max[i]:
                comp += 1
        proba = comp/nb_sim
        liste_proba.append(proba)

    plt.figure(figsize = (8, 5))
    plt.plot(liste_nb_tas_max, liste_proba)
    plt.xlabel("nombre de tas max")
    plt.ylabel("probabilité")
    plt.title("probabilité de gagner au jeu de reussite en fonction de nombre de tas max")
    plt.grid()
    plt.show()
    return liste_proba

def meilleur_echange_consecutif(liste_pioche):
    nb_tas_final = len(reussite_mode_auto(liste_pioche,affiche=False))
    pioche=liste_pioche.copy()
    pioche[0],pioche[1] = pioche[1],pioche[0]#echange consecutif
    nb_tas_echange_optimal=len(reussite_mode_auto(pioche,affiche=False))
    meilleure_pioche=pioche.copy()
    d_optimal=nb_tas_final-nb_tas_echange_optimal#la difference optimale
    i=1
    while i< (len(liste_pioche)-1):
        pioche=liste_pioche.copy()
        pioche[i],pioche[i+1]=pioche[i+1], pioche[i]
        nb_tas_echange=len(reussite_mode_auto(pioche,affiche=False))
        d=nb_tas_final-nb_tas_echange
        if d>0 and  d>=d_optimal:
            nb_tas_echange_optimal=nb_tas_echange
            d_optimal = d
            meilleure_pioche = pioche.copy()
        i+=1
    return meilleure_pioche, d_optimal


#je fait la copie pour pouvoir recuperer le retour qui me donner

def meilleur_echange_consecutif_copie(liste_pioche):
    nb_tas_final = len(reussite_mode_auto(liste_pioche,affiche=False))
    pioche=liste_pioche.copy()
    pioche[0],pioche[1] = pioche[1],pioche[0]#echange consecutif
    nb_tas_echange_optimal=len(reussite_mode_auto(pioche,affiche=False))
    meilleure_pioche=pioche.copy()
    d_optimal=nb_tas_final-nb_tas_echange_optimal#la difference optimale
    i=1
    while i < (len(liste_pioche)-1):
        pioche = liste_pioche.copy()
        pioche[i],pioche[i+1] = pioche[i+1], pioche[i]
        nb_tas_echange = len(reussite_mode_auto(pioche,affiche=False))
        d=nb_tas_final-nb_tas_echange
        if d>0 and  d>=d_optimal:
            nb_tas_echange_optimal=nb_tas_echange
            d_optimal = d
            meilleure_pioche = pioche.copy()
        i+=1
    return meilleure_pioche 

def verifier_statistiques_nb_tas(liste, nb_sim, nb_cartes = 32 ):
    retour = statistiques_nb_tas(nb_sim, nb_cartes = nb_cartes )
    return retour
    

    

    
    
    




                
        
        
        
    
    
   
    
        
        
    
 
        
    
    
    
            
            

    
    
    
    
    

        
        
        
        
        
       
    
       


                
                
                
    
    
    
                          

if __name__=="__main__":
    """print(carte_to_chaine({'valeur':10, 'couleur': 'T'}))
    print(carte_to_chaine({'valeur':'R', 'couleur': 'P'}))
    #----------------------------- question 4.1.2
    listes=[{'valeur':7, 'couleur': 'T'}, 
           {'valeur':10, 'couleur': 'K'}, 
           {'valeur':'R', 'couleur': 'C'}]
    afficher_reussite(listes)
    #----------------------------- question 4.2.1
    print(init_pioche_alea(52))
    
    print(len(init_pioche_alea(52)))
    
    print(init_pioche_alea(32))
    
    print(len(init_pioche_alea(32)))
    
    #----------------------------- question 4.2.2
    liste_carte = init_pioche_fichier('data_init.txt')
    print(liste_carte, len(liste_carte))
    
    pioche = init_pioche_alea(52)
    ecrire_fichier_reussite('datas_init.txt', liste_carte)
    
    print(len(liste_carte))
    print('liste de carte du fichier data_init :', liste_carte)
   
    
    # ----------------------------- question 4.3
    pioche_melange = init_pioche_alea()
    print(pioche_melange)
    pioche = init_pioche_alea(52)
    print(pioche, len(pioche))
    #print(ecrire_fichier_reussite('ordre.txt', pioche))
    
    
    # ----------------------------- question 4.4.1
    carte1={'valeur':7, 'couleur':'P'}
    carte2={'valeur':7, 'couleur':'C'}
    resultat=alliance(carte1, carte2)
    print(resultat)
    # ----------------------------- question 4.4.1
    carte1={'valeur':7, 'couleur':'P'} # autre exemple
    carte2={'valeur':'R', 'couleur':'C'}
    resultat=alliance(carte1, carte2)
    print(resultat)
    #----------------------------- question 4.1.2
    liste = [{'valeur':9, 'couleur': 'T'},{'valeur':'V', 'couleur': 'K'},{'valeur':10, 'couleur': 'C'},{'valeur':'A', 'couleur': 'P'}
            ,{'valeur':'V', 'couleur': 'T'}, {'valeur':'D', 'couleur': 'T'}, {'valeur':'D', 'couleur': 'P'}]
    pioche = [{'valeur':7, 'couleur': 'T'}]
    #pioche=[{'valeur':7, 'couleur': 'T'}, {'valeur':10, 'couleur': 'K'}, {'valeur':'R', 'couleur': 'C'},
           #{'valeur':', 'couleur': 'P'}, {'valeur':'R', 'couleur': 'C'}]
    print(saut_si_possible( liste, 1))
    # ----------------------------- question 4.4.2
    print(saut_si_possible( liste, 2))
    #print(l)
    # ----------------------------- question 4.4.3
    affichers_reussite(liste)
    
    #print('--'*10)
    une_etape_reussite(liste, pioche, True)
    # ----------------------------- question 4.4.3
    liste_pioche = init_pioche_alea()
    reussite_mode_auto(liste_pioche, affiche=True)
    # ----------------------------- question 4.4.4
    liste_pioche = init_pioche_alea()
    reussite_mode_manuel(liste_pioche, 2)
    # ----------------------------- question 4.4.5
    resultat = lance_reussite('auto',52 , 2 ,True)
    print(len(resultat))
    print(resultat)
    # ----------------------------- question 4.4.5
    resultat = lance_reussite('manuel',52 , 2 ,True)
    print(len(resultat))
    print(resultat)
    # ----------------------------- question Partie Extension
    liste_pioche =  [{'couleur': 'K', 'valeur': 7}, {'couleur': 'T', 'valeur': 'A'}, {'couleur': 'C', 'valeur': 'V'}, {'couleur': 'C', 'valeur': 4}, {'couleur': 'P', 'valeur': 'V'}, {'couleur': 'T', 'valeur': 'V'}, {'couleur': 'C', 'valeur': 'D'}, {'couleur': 'P', 'valeur': 7}, {'couleur': 'C', 'valeur': 8}, {'couleur': 'T', 'valeur': 'D'}, {'couleur': 'T', 'valeur': 5}, {'couleur': 'K', 'valeur': 'R'}, {'couleur': 'P', 'valeur': 5}, {'couleur': 'T', 'valeur': 6}, {'couleur': 'T', 'valeur': 2}, {'couleur': 'T', 'valeur': 7}, {'couleur': 'K', 'valeur': 'D'}, {'couleur': 'K', 'valeur': 8}, {'couleur': 'C', 'valeur': 10}, {'couleur': 'C', 'valeur': 9}, {'couleur': 'K', 'valeur': 4}, {'couleur': 'K', 'valeur': 9}, {'couleur': 'P', 'valeur': 2}, {'couleur': 'K', 'valeur': 2}, {'couleur': 'K', 'valeur': 6}, {'couleur': 'C', 'valeur': 'A'}, {'couleur': 'C', 'valeur': 'R'}, {'couleur': 'K', 'valeur': 3}, {'couleur': 'K', 'valeur': 'V'}, {'couleur': 'P', 'valeur': 'A'}, {'couleur': 'P', 'valeur': 3}, {'couleur': 'T', 'valeur': 4}, {'couleur': 'C', 'valeur': 3}, {'couleur': 'P', 'valeur': 9}, {'couleur': 'K', 'valeur': 5}, {'couleur': 'C', 'valeur': 5}, {'couleur': 'K', 'valeur': 10}, {'couleur': 'C', 'valeur': 6}, {'couleur': 'T', 'valeur': 9}, {'couleur': 'P', 'valeur': 'R'}, {'couleur': 'P', 'valeur': 8}, {'couleur': 'P', 'valeur': 10}, {'couleur': 'T', 'valeur': 8}, {'couleur': 'T', 'valeur': 3}, {'couleur': 'K', 'valeur': 'A'}, {'couleur': 'C', 'valeur': 2}, {'couleur': 'P', 'valeur': 4}, {'couleur': 'T', 'valeur': 10}, {'couleur': 'T', 'valeur': 'R'}, {'couleur': 'P', 'valeur': 6}, {'couleur': 'P', 'valeur': 'D'}, {'couleur': 'C', 'valeur': 7}]
    print(verifier_pioche(liste_pioche ))
    print(len(liste_pioche))
    print(liste_pioche)
    # ----------------------------- question Partie Extension
    print(res_multi_simulation(4, 32))
    # ----------------------------- question Partie Extension
    print(statistiques_nb_tas(4, 32))"""
    # ----------------------------- question Partie Extension
    liste_nb_tas_max  =  list(range(2, 33))
    #liste_nb_tas_max  = [5, 7]
    liste_proba = proba(15, liste_nb_tas_max, 32)# pour avoir un calcule 
    print(liste_proba)
    # ----------------------------- question Partie Extension
    """liste_pioche = init_pioche_alea(32)
    val = meilleur_echange_consecutif(liste_pioche)
    val1 = meilleur_echange_consecutif_copie(liste_pioche)
    print(val)
    print(verifier_statistiques_nb_tas(val1, 4, 32 ))"""
    
    
    
    

     
    
    
    
    


























    
   
   
    
   
    
    
    
    
